# ID: 72633490

def broken_search(nums, target) -> int:
    left, right = 0, len(nums) - 1
    while left <= right:
        l_num = nums[left]
        if l_num == target:
            return left
        r_num = nums[right]
        if r_num == target:
            return right
        mid = (left + right) // 2
        pivot = nums[mid]
        if target == pivot:
            return mid
        if l_num < pivot:
            if l_num < target < pivot:
                right = mid - 1
            else:
                left = mid + 1
        else:
            if pivot < target < r_num:
                left = mid + 1
            else:
                right = mid - 1
    return -1
